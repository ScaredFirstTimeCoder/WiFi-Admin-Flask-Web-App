from flask import Flask, render_template, request, redirect, jsonify, url_for, session, render_template_string, send_file, flash
import pymysql, requests, re, subprocess, json, os, logging, urllib3, threading, time
from datetime import datetime, timedelta
now = datetime.now()

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'users_config.json')
settings_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings_config.json')
log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'admin_actions.log')
mac_store = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'authorized_macs.json')

alias_watcher_thread = None
alias_watcher_stop = threading.Event()

def restart_alias_watcher(reason="manual"):
    global alias_watcher_thread
    alias_watcher_stop.set()
    if alias_watcher_thread and alias_watcher_thread.is_alive():
        alias_watcher_thread.join(timeout=5)
    alias_watcher_stop.clear()
    alias_watcher_thread = threading.Thread(target=alias_watcher, daemon=True)
    alias_watcher_thread.start()
    logging.info(f"Alias watcher restarted (reason: {reason})")

def restart_wifiadmin_service(reason="unspecified", delay=2):
    def delayed_restart():
        time.sleep(delay)
        try:
            subprocess.run(["sudo", "systemctl", "restart", "freeradius_frontend.service"], check=True)
            logging.info(f"freeradius_frontend.service restarted silently after {delay}s (reason: {reason})")
        except subprocess.CalledProcessError as e:
            logging.error(f"Restart failed: {e}")
        except Exception as e:
            logging.exception("Unexpected error during restart")

    threading.Thread(target=delayed_restart, daemon=True).start()

def alias_watcher():
    last_seen = set()

    while True:
        try:
            settings = load_settings()
            online_macs = get_online_macs(settings)
            online_set = set(online_macs)

            # Load alias log
            try:
                with open("mac_alias.json") as f:
                    aliased = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                aliased = []

            aliased_macs = {entry["mac_address"].lower() for entry in aliased}

            # Detect new MACs
            new_macs = online_set - aliased_macs
            if new_macs and new_macs != last_seen:
                count = set_unifi_aliases()
                logging.info(f"{count} new aliases set by alias watcher")
                last_seen = new_macs

        except Exception as e:
            logging.error(f"Alias watcher error: {e}")

        time.sleep(30)  # Poll every 30 seconds

def cleanup_expired_macs():
    try:
        with open(mac_store, "r") as f:
            mac_list = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        mac_list = []

    now = datetime.now()
    valid_macs = []

    for entry in mac_list:
        expires_at = datetime.fromisoformat(entry["expires_at"])  # offset-naive
        if expires_at > datetime.now():  # also offset-naive
            valid_macs.append(entry)

    if len(valid_macs) != len(mac_list):
        with open(mac_store, "w") as f:
            json.dump(valid_macs, f, indent=2)

        return len(mac_list) - len(valid_macs)
    return 0


with open(settings_path) as f:
    CONFIG = json.load(f)

logging.basicConfig(
    filename=log_path,
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

app = Flask(__name__)
app.secret_key = 'your-secret-key'

@app.template_filter("time_remaining")
def time_remaining_filter(iso):
    from datetime import datetime
    try:
        expires = datetime.fromisoformat(iso)
        delta = expires - datetime.now()
        days = delta.days
        hours = delta.seconds // 3600
        return f"{days}d {hours}h" if days >= 0 else "expired"
    except:
        return "unknown"

def get_db():
    db = CONFIG["db"]
    return pymysql.connect(
        host=db["host"],
        user=db["user"],
        password=db["password"],
        database=db["database"],
        cursorclass=pymysql.cursors.DictCursor
    )
def restart_freeradius():
    try:
        subprocess.run(['sudo', 'systemctl', 'restart', 'freeradius'], check=True)
    except Exception as e:
        print("FreeRADIUS restart failed:", e)

def normalize_mac(mac_raw):
    mac = re.sub(r'[^0-9a-fA-F]', ':', mac_raw).lower()
    parts = mac.split(':')
    return ':'.join(part.zfill(2) for part in parts if part) if len(parts) == 6 else None

def disconnect_unifi_client(mac):
    unifi = CONFIG["unifi"]
    UNIFI_URL = unifi["base_url"]
    UNIFI_USER = unifi["username"]
    UNIFI_PASS = unifi["password"]
    UNIFI_SITE = unifi["site"]

    session_req = requests.Session()
    session_req.verify = False
    login_payload = {'username': UNIFI_USER, 'password': UNIFI_PASS}
    resp = session_req.post(f"{UNIFI_URL}/api/login", json=login_payload)
    if resp.status_code != 200:
        return False

    mac = normalize_mac(mac)
    payload = {"cmd": "unauthorize-guest", "mac": mac}
    resp = session_req.post(f"{UNIFI_URL}/api/s/{UNIFI_SITE}/cmd/stamgr", json=payload)
    return resp.status_code == 200

def update_unifi_mac_filter(mac, action):
    mac = normalize_mac(mac)
    unifi = CONFIG["unifi"]
    wlan_id = unifi.get("wlan_id")

    session_req = requests.Session()
    session_req.verify = False
    login_payload = {"username": unifi["username"], "password": unifi["password"]}
    login = session_req.post(f"{unifi['base_url']}/api/login", json=login_payload)
    if login.status_code != 200:
        logging.warning("UniFi login failed for MAC filter update")
        return

    wlan_resp = session_req.get(f"{unifi['base_url']}/api/s/{unifi['site']}/rest/wlanconf/{wlan_id}")
    if wlan_resp.status_code != 200:
        logging.warning("Failed to fetch WLAN config")
        return

    wlan = wlan_resp.json().get("data", [{}])[0]
    mac_filter_list = wlan.get("mac_filter_list", [])

    if action == "add" and mac not in mac_filter_list:
        mac_filter_list.append(mac)
    elif action == "remove" and mac in mac_filter_list:
        mac_filter_list.remove(mac)

    wlan["mac_filter_list"] = mac_filter_list
    update_resp = session_req.put(f"{unifi['base_url']}/api/s/{unifi['site']}/rest/wlanconf/{wlan_id}", json=wlan)
    if update_resp.status_code == 200:
        logging.info(f"MAC {mac} {action}ed in UniFi MAC filter")
    else:
        logging.warning(f"Failed to {action} MAC {mac} in UniFi MAC filter")


def load_user_data():
    try:
        with open(config_path) as f:
            return json.load(f)
    except Exception as e:
        logging.warning(f"Failed to load user data: {e}")
        return {}

def save_user_data(data):
    try:
        with open(config_path, 'w') as f:
            json.dump(data, f, indent=2)
        logging.info("User data saved successfully")
    except Exception as e:
        logging.error(f"Failed to save user data: {e}")

def load_settings():
    if not os.path.exists(settings_path):
        with open(settings_path, 'w') as f:
            json.dump({}, f, indent=2)
        logging.info("Created empty settings_config.json")

    try:
        with open(settings_path) as f:
            return json.load(f)
    except Exception as e:
        logging.warning(f"Failed to load settings: {e}")
        return {}

def save_settings(data):
    try:
        with open(settings_path, 'w') as f:
            json.dump(data, f, indent=2)
        logging.info("Settings saved successfully")
    except Exception as e:
        logging.error(f"Failed to save settings: {e}")

def load_authorized_macs():
    if not os.path.exists(mac_store):
        return []
    with open(mac_store, "r") as f:
        return json.load(f)

def save_authorized_macs(mac_list):
    with open(mac_store, "w") as f:
        json.dump(mac_list, f, indent=2)

def add_mac_entry(mac, description, days):
    now = datetime.now()
    expires = now + timedelta(days=days)
    mac_list = load_authorized_macs()

    # Remove duplicates
    mac_list = [m for m in mac_list if m["mac_address"].lower() != mac.lower()]

    mac_list.append({
        "mac_address": mac,
        "description": description,
        "authorized_at": now.isoformat(),
        "expires_at": (now + timedelta(days=days)).isoformat()
    })
    save_authorized_macs(mac_list)

    update_unifi_mac_filter(mac, action="add")

def remove_mac_entry(mac):
    mac_list = load_authorized_macs()
    mac_list = [m for m in mac_list if m["mac_address"].lower() != mac.lower()]
    save_authorized_macs(mac_list)

    update_unifi_mac_filter(mac, action="remove")

def remove_mac_alias(mac_address):
    mac_address = mac_address.lower()
    alias_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mac_alias.json")

    if not os.path.exists(alias_path):
        logging.info("Alias file not found, skipping removal")
        return

    try:
        with open(alias_path, "r") as f:
            aliases = json.load(f)
    except Exception as e:
        logging.warning(f"Failed to load alias file: {e}")
        return

    # If aliases is a list of dicts (not a dict), convert it
    if isinstance(aliases, list):
        aliases = {entry["mac_address"].lower(): entry for entry in aliases if "mac_address" in entry}

    if mac_address in aliases:
        del aliases[mac_address]
        with open(alias_path, "w") as f:
            json.dump(list(aliases.values()), f, indent=2)
        logging.info(f"Removed MAC alias for {mac_address}")
    else:
        logging.info(f"No alias found for MAC {mac_address}, nothing to remove")
        #restart_wifiadmin_service(reason=f"MAC aliases removed for user {id}", delay=2)
                
def get_online_macs(settings):
    import requests
    session = requests.Session()
    session.verify = False

    try:
        login = session.post(f"{settings['unifi']['base_url']}/api/login", json={
            "username": settings["unifi"]["username"],
            "password": settings["unifi"]["password"]
        })
        if login.status_code != 200:
            return set()

        clients = session.get(f"{settings['unifi']['base_url']}/api/s/{settings['unifi']['site']}/stat/sta")
        if clients.status_code != 200:
            return set()

        return set(c["mac"].lower() for c in clients.json()["data"] if c.get("authorized"))
    except Exception:
        return set()
    
def set_unifi_aliases():
    alias_log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mac_alias.json')

    # Load alias log
    try:
        with open(alias_log_path) as f:
            aliased = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        aliased = []

    aliased_macs = {entry["mac_address"].lower() for entry in aliased}

    # Load authorized MACs
    authorized_macs = load_authorized_macs()
    mac_map = {}
    for entry in authorized_macs:
        mac = entry["mac_address"].lower()
        description = entry.get("description", "Device")
        username = entry.get("username")
        alias = f"{description} - {username}" if username else description
        mac_map[mac] = {
            "mac_address": mac,
            "description": description,
            "username": username,
            "alias": alias
    }

    # Load RADIUS users
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT rc.username, rc.description, mb.mac_address
        FROM radcheck rc
        LEFT JOIN mac_bindings mb ON mb.username = rc.username
        WHERE rc.attribute = 'Cleartext-Password'
    """)
    radius_users = cur.fetchall()
    conn.close()

    for r in radius_users:
        mac = (r["mac_address"] or "").lower()
        if mac:
            description = r.get("description", "Device")
            username = r["username"]
            alias = f"{description} - {username}" if username else description
            mac_map[mac] = {
                "mac_address": mac,
                "description": description,
                "username": username,
                "alias": alias
         }

    # Get online MACs
    settings = load_settings()
    online_macs = get_online_macs(settings)

    # UniFi login
    unifi = settings["unifi"]
    session_req = requests.Session()
    session_req.verify = False
    login_payload = {"username": unifi["username"], "password": unifi["password"]}
    login = session_req.post(f"{unifi['base_url']}/api/login", json=login_payload)
    if login.status_code != 200:
        return 0

    new_aliases = []

    for mac in online_macs:
        if mac in mac_map and mac not in aliased_macs:
            user = mac_map[mac]
            alias = user["alias"]
            # Try /rest/user/{mac}
            get_url = f"{unifi['base_url']}/api/s/{unifi['site']}/rest/user/{mac}"
            resp = session_req.get(get_url)
            client_data = resp.json().get("data", [])

            # Fallback to /stat/sta
            if not client_data:
                resp = session_req.get(f"{unifi['base_url']}/api/s/{unifi['site']}/stat/sta")
                client_data = [c for c in resp.json().get("data", []) if c["mac"].lower() == mac]

            # Fallback to /stat/alluser
            if not client_data:
                resp = session_req.get(f"{unifi['base_url']}/api/s/{unifi['site']}/stat/alluser")
                client_data = [c for c in resp.json().get("data", []) if c["mac"].lower() == mac]

            if client_data:
                client = client_data[0]
                client_id = client["_id"]
                client["name"] = alias
                client["noted"] = True
                update_url = f"{unifi['base_url']}/api/s/{unifi['site']}/rest/user/{client_id}"
                resp = session_req.put(update_url, json=client)
                if resp.status_code == 200 and resp.json().get("meta", {}).get("rc") == "ok":
                    new_aliases.append({
                        "mac_address": mac,
                        "alias": alias,
                        "timestamp": datetime.now().isoformat()
                    })

    if new_aliases:
        aliased.extend(new_aliases)
        with open(alias_log_path, "w") as f:
            json.dump(aliased, f, indent=2)

    return len(new_aliases)

@app.route('/login', methods=['GET', 'POST'])
def login():
    users = load_user_data()
    if request.method == 'POST':
        username = request.form.get('username', '').strip().lower()
        password = request.form.get('password', '').strip()

        #print("Login attempt:", username, password)
        #print("Loaded users:", users)

        if username in users and users[username]['password'] == password:
            session['username'] = username
            session['role'] = users[username].get('role', 'user')
            return redirect(url_for('index'))

        return render_template('login.html', error="Invalid credentials")

    return render_template('login.html')

@app.route("/authorize_mac", methods=["GET", "POST"])
def authorize_mac():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == "POST":
        mac_raw = request.form.get("mac", "").strip()
        days = request.form.get("days", "").strip()
        description = request.form.get("description", "").strip()

        mac = normalize_mac(mac_raw)
        if not mac or not days.isdigit():
            return redirect(url_for("authorize_mac", message="Invalid MAC or days value"))
        
        # Conflict check against RADIUS
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT mac_address FROM mac_bindings")
        radius_macs = {row["mac_address"].lower() for row in cur.fetchall()}
        conn.close()

        if mac.lower() in radius_macs:
            return redirect(url_for("authorize_mac", message=f"MAC {mac} already exists in Users."))
        
        days_int = int(days)
        timeout_seconds = days_int * 86400

        # 🔧 UniFi API call
        unifi = CONFIG["unifi"]
        session_req = requests.Session()
        session_req.verify = False

        login_payload = {"username": unifi["username"], "password": unifi["password"]}
        login = session_req.post(f"{unifi['base_url']}/api/login", json=login_payload)

        if login.status_code != 200:
            return redirect(url_for("authorize_mac", message="UniFi login failed"))

        payload = {"cmd": "authorize-guest", "mac": mac, "minutes": timeout_seconds // 60}
        resp = session_req.post(f"{unifi['base_url']}/api/s/{unifi['site']}/cmd/stamgr", json=payload)

        if resp.status_code == 200:
            add_mac_entry(mac, description, days_int)
            restart_alias_watcher(reason=f"MAC authorized: {mac}")
            return redirect(url_for("index", tab="authorized_macs", message=f"MAC {mac} authorized for {days_int} days"))
        else:
            return redirect(url_for("authorize_mac", message="Authorization failed"))
        
    #restart_wifiadmin_service(delay=2)
    message = request.args.get("message", "")
    return render_template("authorize_mac.html", flash_message=message)
    
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/edit_user_admin/<username>', methods=['GET', 'POST'])
def edit_user_admin(username):
    users = load_user_data()
    key = username.strip().lower()

    if key not in users:
        return "User not found", 404

    if request.method == 'POST':
        new_password = request.form.get('password', '').strip()
        if new_password:
            users[key]['password'] = new_password
            save_user_data(users)
            return redirect(url_for('index'))
        else:
            return "Password cannot be empty", 400

    return render_template_string("""
    <form method="post" style="max-width:400px;margin:40px auto;display:grid;gap:10px">
     <h2>Change Password</h2>
     <input name="username" value="{{ user.username }}" readonly>
     <input name="password" type="password" placeholder="New Password" required>

     <div style="display:flex; gap:10px;">
     <button type="submit">Save</button>
     <a href="/" style="text-decoration:none;">
     <button type="button">Cancel</button>
     </a>
     </div>
    </form>
    """, user={'username': key})  

@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))

    # Handle tab and message from redirect
    tab = request.args.get("tab", "users")
    message = request.args.get("message", "")

    settings = load_settings()
    online_macs = get_online_macs(settings)
    show_only_online = session.get("show_only_online", False)

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT rc.id, rc.description, rc.username, rc.value AS password,
               mb.mac_address, rug.groupname AS vlan
        FROM radcheck rc
        LEFT JOIN mac_bindings mb ON mb.username = rc.username
        LEFT JOIN radusergroup rug ON rug.username = rc.username
        WHERE rc.attribute = 'Cleartext-Password'
        ORDER BY LOWER(COALESCE(rc.description, rc.username))
    """)

    user_list = cursor.fetchall()
    for user in user_list:
        mac = (user["mac_address"] or "").lower()
        user["is_online"] = mac in online_macs

    if show_only_online:
        user_list = [u for u in user_list if u["is_online"]]

    try:
        cursor.execute("SELECT * FROM nas ORDER BY nasname")
        nas_list = cursor.fetchall()
    except:
        nas_list = []
    conn.close()

    user_roles = load_user_data()
    authorized_macs = load_authorized_macs()

    #authorized_mac_list = [m["mac_address"].lower() for m in authorized_macs]
    #radius_mac_list = [u["mac_address"].lower() for u in user_list if u["mac_address"]]

    return render_template('index.html',
        user_list=user_list,
        nas_list=nas_list,
        user_roles=user_roles,
        authorized_macs=authorized_macs,
        #authorized_mac_list=authorized_mac_list,
        #radius_mac_list=radius_mac_list,
        session=session,
        show_mac_column=session.get("show_mac_column", False),
        show_only_online=show_only_online,
        active_tab=tab,
        flash_message=message
    )
# -----------------------------------------------------------------------------
# RADIUS Users CRUD (with MAC binding and VLAN assignment)
# -----------------------------------------------------------------------------
@app.route('/add_user', methods=['GET', 'POST'])
def add_user():
    if request.method == 'POST':
        description = request.form.get('description')
        username = request.form['username']
        password = request.form['password']
        vlan_id = request.form.get('vlan_id')
        mac_address = request.form.get('mac_address')

        if mac_address:
            mac_address = mac_address.lower()
            authorized_macs = load_authorized_macs()
            authorized_set = {m["mac_address"].lower() for m in authorized_macs}
            if mac_address in authorized_set:
                return f"MAC address {mac_address} already exists in Authorized MACs.", 400

        conn = get_db()
        cur = conn.cursor()

        # Unique username
        cur.execute("SELECT COUNT(*) AS count FROM radcheck WHERE username=%s", (username,))
        exists = cur.fetchone()['count']
        if exists:
            conn.close()
            return "Username already exists. Please choose a different one.", 400

        # Insert password row
        cur.execute("""
            INSERT INTO radcheck (description, username, attribute, op, value)
            VALUES (%s, %s, 'Cleartext-Password', ':=', %s)
        """, (description, username, password))

        # MAC binding with conflict check
        if mac_address:
            cur.execute("SELECT username FROM mac_bindings WHERE mac_address=%s", (mac_address,))
            existing = cur.fetchone()
            if existing and existing['username'] != username:
                conn.close()
                return f"MAC address {mac_address} is already bound to user '{existing['username']}'.", 400

            cur.execute("""
                INSERT INTO mac_bindings (username, mac_address)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE mac_address = VALUES(mac_address)
            """, (username, mac_address))

            update_unifi_mac_filter(mac_address, "add")

        # VLAN assignment via group linkage
        if vlan_id:
            groupname = str(vlan_id)
            cur.execute("SELECT COUNT(*) AS count FROM radgroupreply WHERE groupname=%s", (groupname,))
            gexists = cur.fetchone()['count']
            if not gexists:
                cur.executemany("""
                    INSERT INTO radgroupreply (groupname, attribute, op, value)
                    VALUES (%s, %s, %s, %s)
                """, [
                    (groupname, 'Tunnel-Type', '=', '13'),
                    (groupname, 'Tunnel-Medium-Type', '=', '6'),
                    (groupname, 'Tunnel-Private-Group-Id', '=', vlan_id)
                ])
            cur.execute("""
                INSERT INTO radusergroup (username, groupname, priority)
                VALUES (%s, %s, 1)
            """, (username, groupname))

        conn.commit()
        logging.info(f"Admin '{session.get('username')}' added RADIUS user '{username}' with VLAN '{vlan_id}' and MAC '{mac_address}'")
        conn.close()
        restart_freeradius()
        restart_alias_watcher(reason=f"MAC added for user {username}")
        return redirect(url_for('index'))

    return render_template('user_form.html', action='Add', user=None)

@app.route('/edit_user/<int:id>', methods=['GET', 'POST'])
def edit_user(id: int):
    conn = get_db()
    cur = conn.cursor()

    if request.method == 'POST':
        description = request.form.get('description')
        new_username = request.form['username']
        password = request.form['password']
        vlan_id = request.form.get('vlan_id')
        mac_address = request.form.get('mac_address')

        # Determine original username by id
        cur.execute("SELECT username FROM radcheck WHERE id=%s", (id,))
        original = cur.fetchone()
        old_username = original['username'] if original else new_username

        # Disconnect UniFi client if MAC cleared
        cur.execute("SELECT mac_address FROM mac_bindings WHERE username=%s", (old_username,))
        old_mac = cur.fetchone()
        if old_mac and not mac_address:
            mac = old_mac['mac_address']
            disconnect_unifi_client(mac)
            remove_mac_entry(mac)
            remove_mac_alias(mac)
            update_unifi_mac_filter(mac, action="remove")
            #restart_wifiadmin_service(reason=f"MAC aliases removed for user {id}", delay=2)


        # Update the password row (id row)
        cur.execute("""
            UPDATE radcheck
            SET description=%s, username=%s, value=%s
            WHERE id=%s
        """, (description, new_username, password, id))

        # Clean old links for username (we re-add clean state)
        cur.execute("DELETE FROM radusergroup WHERE username=%s", (old_username,))
        cur.execute("DELETE FROM mac_bindings WHERE username=%s", (old_username,))

        # Re-bind MAC if provided (conflict-check)
        if mac_address:
            cur.execute("SELECT username FROM mac_bindings WHERE mac_address=%s", (mac_address,))
            existing = cur.fetchone()
            if existing and existing['username'] != new_username:
                conn.rollback()
                conn.close()
                return f"MAC address {mac_address} is already bound to user '{existing['username']}'.", 400

            cur.execute("""
                INSERT INTO mac_bindings (username, mac_address)
                VALUES (%s, %s)
                ON DUPLICATE KEY UPDATE mac_address = VALUES(mac_address)
            """, (new_username, mac_address))

            update_unifi_mac_filter(mac_address, action="add")

        # Re-assign VLAN if provided
        if vlan_id:
            groupname = str(vlan_id)
            cur.execute("SELECT COUNT(*) AS count FROM radgroupreply WHERE groupname=%s", (groupname,))
            gexists = cur.fetchone()['count']
            if not gexists:
                cur.executemany("""
                    INSERT INTO radgroupreply (groupname, attribute, op, value)
                    VALUES (%s, %s, %s, %s)
                """, [
                    (groupname, 'Tunnel-Type', '=', '13'),
                    (groupname, 'Tunnel-Medium-Type', '=', '6'),
                    (groupname, 'Tunnel-Private-Group-Id', '=', vlan_id)
                ])
            cur.execute("""
                INSERT INTO radusergroup (username, groupname, priority)
                VALUES (%s, %s, 1)
            """, (new_username, groupname))

        conn.commit()
        logging.info(f"Admin '{session.get('username')}' edited RADIUS user '{new_username}' (ID {id}) — VLAN '{vlan_id}', MAC '{mac_address}'")
        conn.close()
        if mac_address:
            restart_alias_watcher(reason=f"MAC updated for user {new_username}")
        restart_freeradius()
        return redirect(url_for('index'))

    # GET: build user dict for form
    cur.execute("SELECT * FROM radcheck WHERE id=%s", (id,))
    user = cur.fetchone()
    if not user:
        conn.close()
        return "User not found", 404

    # VLAN via radusergroup
    cur.execute("SELECT groupname FROM radusergroup WHERE username=%s", (user['username'],))
    group = cur.fetchone()
    user['vlan_id'] = group['groupname'] if group else ''

    # MAC via mac_bindings
    cur.execute("SELECT mac_address FROM mac_bindings WHERE username=%s", (user['username'],))
    mac = cur.fetchone()
    user['mac_address'] = mac['mac_address'] if mac else ''

    conn.close()
    return render_template('user_form.html', action='Edit', user=user)

@app.route('/delete_user/<int:id>')
def delete_user(id: int):
    conn = get_db()
    cur = conn.cursor()

    # Find username for this id (password row)
    cur.execute("SELECT username FROM radcheck WHERE id=%s", (id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return redirect(url_for('index'))

    username = row['username']

    # Cache MACs to unauthorize after deletion
    cur.execute("SELECT mac_address FROM mac_bindings WHERE username=%s", (username,))
    macs = [r['mac_address'] for r in cur.fetchall()]

    # Delete linked rows
    cur.execute("DELETE FROM radusergroup WHERE username=%s", (username,))
    cur.execute("DELETE FROM mac_bindings WHERE username=%s", (username,))
    cur.execute("DELETE FROM radreply WHERE username=%s", (username,))
    cur.execute("DELETE FROM radcheck WHERE id=%s", (id,))
    conn.commit()
    logging.info(f"Admin '{session.get('username')}' deleted RADIUS user '{username}' (ID {id})")
    conn.close()

    # Unauthorize clients
    for m in macs:
        disconnect_unifi_client(m)
        remove_mac_alias(m)

        #update_unifi_mac_filter(m, action="remove")

    #restart_wifiadmin_service(reason=f"MAC aliases removed for user {id}", delay=2)
    restart_freeradius()
    return redirect(url_for('index'))
   

# -----------------------------------------------------------------------------
# Async MAC unauthorize (used by Delete button in form)
# -----------------------------------------------------------------------------
@app.route("/unauthorize_mac", methods=["POST"])
def unauthorize_mac():
    if 'username' not in session:
        return jsonify(success=False, error="Not logged in"), 401

    try:
        mac = request.get_json().get("mac_address", "").strip()
        if not mac:
            return jsonify(success=False, error="No MAC address provided"), 400

        unifi = CONFIG["unifi"]
        session_req = requests.Session()
        session_req.verify = False

        login_payload = {"username": unifi["username"], "password": unifi["password"]}
        login = session_req.post(f"{unifi['base_url']}/api/login", json=login_payload)

        if login.status_code != 200:
            return jsonify(success=False, error="UniFi login failed"), 500

        payload = {"cmd": "unauthorize-guest", "mac": mac}
        resp = session_req.post(f"{unifi['base_url']}/api/s/{unifi['site']}/cmd/stamgr", json=payload)

        if resp.status_code == 200:
            remove_mac_entry(mac)
            remove_mac_alias(mac)
                  
                        
            return jsonify(success=True)
        else:
            return jsonify(success=False, error="Failed to unauthorize MAC"), 500
    except Exception as e:
        return jsonify(success=False, error=str(e)), 500
    

    
@app.route("/unauthorize_mac_form", methods=["POST"])
def unauthorize_mac_form():
    if 'username' not in session:
        return redirect(url_for('login'))

    mac = request.form.get("mac_address", "").strip()
    if not mac:
        return redirect(url_for("index", tab="authorized_macs", message="No MAC address provided"))

    unifi = CONFIG["unifi"]
    session_req = requests.Session()
    session_req.verify = False

    login_payload = {"username": unifi["username"], "password": unifi["password"]}
    login = session_req.post(f"{unifi['base_url']}/api/login", json=login_payload)

    if login.status_code != 200:
        return redirect(url_for("index", tab="authorized_macs", message="UniFi login failed"))

    payload = {"cmd": "unauthorize-guest", "mac": mac}
    resp = session_req.post(f"{unifi['base_url']}/api/s/{unifi['site']}/cmd/stamgr", json=payload)

    if resp.status_code == 200:
        remove_mac_entry(mac)
        remove_mac_alias(mac)
        
        
        
        return redirect(url_for("index", tab="authorized_macs", message=f"MAC {mac} unauthorized"))
    else:
        return redirect(url_for("index", tab="authorized_macs", message=f"Failed to unauthorize {mac}"))


# -----------------------------------------------------------------------------
# NAS CRUD (optional; index shows NAS if table exists)
# -----------------------------------------------------------------------------
@app.route('/add_nas', methods=['GET', 'POST'])
def add_nas():
    if request.method == 'POST':
        nasname = request.form.get('nasname') or ''
        shortname = request.form.get('shortname') or ''
        type_ = request.form.get('type') or 'other'
        ports = request.form.get('ports') or None
        secret = request.form.get('secret') or ''
        server = request.form.get('server') or None
        community = request.form.get('community') or None
        description = request.form.get('description') or ''

        if not nasname or not secret:
            return "nasname and secret required", 400

        conn = get_db()
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO nas (nasname, shortname, type, ports, secret, server, community, description)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """, (nasname, shortname, type_, ports, secret, server, community, description))
        conn.commit()
        logging.info(f"Admin '{session.get('username')}' added NAS '{nasname}'")
        conn.close()
        restart_freeradius()
        return redirect(url_for('index'))

    return render_template('nas_form.html', action='Add', nas=None)

@app.route('/edit_nas/<int:id>', methods=['GET', 'POST'])
def edit_nas(id: int):
    conn = get_db()
    cur = conn.cursor()

    if request.method == 'POST':
        nasname = request.form.get('nasname') or ''
        shortname = request.form.get('shortname') or ''
        type_ = request.form.get('type') or 'other'
        ports = request.form.get('ports') or None
        secret = request.form.get('secret') or ''
        server = request.form.get('server') or None
        community = request.form.get('community') or None
        description = request.form.get('description') or ''

        cur.execute("""
            UPDATE nas SET nasname=%s, shortname=%s, type=%s, ports=%s, secret=%s,
                           server=%s, community=%s, description=%s
            WHERE id=%s
        """, (nasname, shortname, type_, ports, secret, server, community, description, id))
        conn.commit()
        logging.info(f"Admin '{session.get('username')}' edited NAS '{nasname}' (ID {id})")
        conn.close()
        restart_freeradius()
        return redirect(url_for('index'))

    cur.execute("SELECT * FROM nas WHERE id=%s", (id,))
    nas = cur.fetchone()
    conn.close()
    if not nas:
        return "NAS not found", 404
    return render_template('nas_form.html', action='Edit', nas=nas)

@app.route('/delete_nas/<int:id>')
def delete_nas(id: int):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM nas WHERE id=%s", (id,))
    conn.commit()
    logging.info(f"Admin '{session.get('username')}' deleted NAS (ID {id})")
    conn.close()
    restart_freeradius()
    return redirect(url_for('index'))

# -----------------------------------------------------------------------------
# Optional data endpoints
# -----------------------------------------------------------------------------
@app.route('/add_user_admin', methods=['GET', 'POST'])
def add_user_admin():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')

        users = load_user_data()

        users[username] = {
            "username": username,
            "password": password,
            "role": role
        }

        save_user_data(users)
        #restart_wifiadmin_service(reason=f"MAC aliases removed for user {id}", delay=2)
        return redirect(url_for('index'))
        
    return render_template('add_user_admin.html')
    alias_watcher()

@app.route('/delete_user_admin/<username>', methods=['POST'])
def delete_user_admin(username):
    users = load_user_data()

    # Prevent self-deletion
    if username == session.get('username'):
        return "Cannot delete your own account", 403

    if username in users:
        del users[username]
        save_user_data(users)
        return redirect(url_for('index'))

    return "User not found", 404

@app.route("/online_status")
def online_status():
    settings = load_settings()
    online_macs = get_online_macs(settings)
    return {"online_macs": list(online_macs)}

# -----------------------------------------------------------------------------
# Live export/import
# -----------------------------------------------------------------------------
def scrape_radius_users():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
        SELECT rc.id, rc.description, rc.username, rc.value AS password,
               mb.mac_address, rug.groupname AS vlan
        FROM radcheck rc
        LEFT JOIN mac_bindings mb ON mb.username = rc.username
        LEFT JOIN radusergroup rug ON rug.username = rc.username
        WHERE rc.attribute = 'Cleartext-Password'
        ORDER BY rc.username
    """)
    rows = cur.fetchall()
    conn.close()
    # Return dict keyed by username for stable import
    out = {}
    for r in rows:
        out[r['username']] = {
            "description": r.get('description') or "",
            "username": r['username'],
            "password": r.get('password') or "",
            "mac_address": r.get('mac_address') or "",
            "vlan": str(r.get('vlan')) if r.get('vlan') is not None else ""
        }
    return out

def scrape_nas_clients():
    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute("SELECT * FROM nas ORDER BY nasname")
        rows = cur.fetchall()
    except:
        rows = []
    conn.close()
    # Return dict keyed by nasname for stable import
    out = {}
    for n in rows:
        out[n['nasname']] = {
            "nasname": n.get('nasname', ''),
            "shortname": n.get('shortname', ''),
            "type": n.get('type', ''),
            "ports": n.get('ports'),
            "secret": n.get('secret', ''),
            "server": n.get('server'),
            "community": n.get('community'),
            "description": n.get('description', '')
        }
    return out

@app.route('/export_config')
def export_config():
    admin_users = load_user_data()                 # Frontend admin users
    freeradius_users = scrape_radius_users()       # Live from DB
    nas_clients = scrape_nas_clients()             # Live from DB
    settings = load_settings()                     # File-based settings

    bundle = {
        "admin_users": admin_users,
        "freeradius_users": freeradius_users,
        "nas_clients": nas_clients,
        "settings": settings
    }

    temp_path = '/tmp/freeradius_config.json'
    with open(temp_path, 'w') as f:
        json.dump(bundle, f, indent=2)

    from datetime import datetime

# Get app directory and timestamp
    app_dir = os.path.dirname(os.path.abspath(__file__))
    timestamp = datetime.now().strftime('%Y-%m-%d')
    backup_dir = os.path.join(app_dir, 'backups')
    os.makedirs(backup_dir, exist_ok=True)

# Build timestamped filename
    backup_filename = f"freeradius_config_{timestamp}.json"
    backup_path = os.path.join(backup_dir, backup_filename)

# Save backup copy
    with open(backup_path, 'w') as f:
        json.dump(bundle, f, indent=2)


    return send_file(
        temp_path,
        as_attachment=True,
        download_name='freeradius_config.json',
        mimetype='application/json'
    )

def restore_nas_clients(nas_clients: dict):
    conn = get_db()
    cur = conn.cursor()
    try:
        # Replace-all semantics for deterministic restore
        cur.execute("DELETE FROM nas")
        for nasname, n in nas_clients.items():
            cur.execute("""
                INSERT INTO nas (nasname, shortname, type, ports, secret, server, community, description)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                n.get('nasname') or nasname,
                n.get('shortname') or '',
                n.get('type') or 'other',
                n.get('ports'),
                n.get('secret') or '',
                n.get('server'),
                n.get('community'),
                n.get('description') or ''
            ))
        conn.commit()
    finally:
        conn.close()

def restore_freeradius_users(users: dict):
    # users dict keyed by username with fields: description, password, mac_address, vlan
    conn = get_db()
    cur = conn.cursor()
    try:
        # Replace-all semantics across related tables
        # Caution: This wipes existing users to match the import bundle.
        cur.execute("DELETE FROM radusergroup")
        cur.execute("DELETE FROM mac_bindings")
        cur.execute("DELETE FROM radreply")
        cur.execute("DELETE FROM radcheck")

        for username, u in users.items():
            description = u.get('description') or ''
            password = u.get('password') or ''
            mac_address = u.get('mac_address') or ''
            vlan = u.get('vlan') or ''

            # Insert main password row
            cur.execute("""
                INSERT INTO radcheck (description, username, attribute, op, value)
                VALUES (%s, %s, 'Cleartext-Password', ':=', %s)
            """, (description, username, password))

            # MAC binding
            if mac_address:
                cur.execute("""
                    INSERT INTO mac_bindings (username, mac_address)
                    VALUES (%s, %s)
                    ON DUPLICATE KEY UPDATE mac_address = VALUES(mac_address)
                """, (username, mac_address))

            # VLAN via group
            if vlan:
                groupname = str(vlan)
                # Ensure group exists in radgroupreply
                cur.execute("SELECT COUNT(*) AS count FROM radgroupreply WHERE groupname=%s", (groupname,))
                gexists = cur.fetchone()['count']
                if not gexists:
                    cur.executemany("""
                        INSERT INTO radgroupreply (groupname, attribute, op, value)
                        VALUES (%s, %s, %s, %s)
                    """, [
                        (groupname, 'Tunnel-Type', '=', '13'),
                        (groupname, 'Tunnel-Medium-Type', '=', '6'),
                        (groupname, 'Tunnel-Private-Group-Id', '=', vlan)
                    ])
                cur.execute("""
                    INSERT INTO radusergroup (username, groupname, priority)
                    VALUES (%s, %s, 1)
                """, (username, groupname))

        conn.commit()
    finally:
        conn.close()

@app.route('/import_config', methods=['POST'])
def import_config():
    file = request.files.get('file')
    if not file or not file.filename.endswith('.json'):
        return "Invalid file", 400

    try:
        data = json.load(file)

        # Restore admin users (frontend auth)
        admin_users = data.get('admin_users', {})
        save_user_data(admin_users)

        # Restore NAS clients (DB)
        nas_clients = data.get('nas_clients', {})
        restore_nas_clients(nas_clients)

        # Restore RADIUS users (DB)
        freeradius_users = data.get('freeradius_users', {})
        restore_freeradius_users(freeradius_users)

        # Restore settings (file)
        settings = data.get('settings', {})
        save_settings(settings)

        restart_freeradius()
        return redirect(url_for('index'))
    except Exception as e:
        print("❌ Import failed:", e)
        return "Import error", 500
    
@app.before_request
def auto_cleanup():
    expired_count = cleanup_expired_macs()
    if expired_count:
        logging.info(f"✅ Removed {expired_count} expired MAC(s)")

@app.route("/set_unifi_aliases", methods=["POST"])
def trigger_alias_setter():
    if 'username' not in session:
        return redirect(url_for('login'))

    count = set_unifi_aliases()
    flash(f"{count} new aliases set on UniFi.")
    return redirect(url_for("index"))
    
@app.errorhandler(500)
def internal_error(e):
    return "Something went wrong. Please check UniFi or database connectivity.", 500

@app.errorhandler(403)
def forbidden(e):
    return "Access denied. Check your credentials or permissions.", 403

@app.errorhandler(503)
def service_unavailable(e):
    return "Service unavailable. UniFi or database may be offline.", 503

# -----------------------------------------------------------------------------
# Entry
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    watcher_thread = threading.Thread(target=alias_watcher, daemon=True)
    watcher_thread.start()
    app.run(host="0.0.0.0", port=5000, debug=False)    